# Crimson Desert Save Editor – Android ARM64 prototype

Android source project for inspecting a Crimson Desert save and exporting a cleaned **copy**. The original selected save is never overwritten.

## Included
- Android document picker for opening a `.save` file and choosing a separate export destination.
- JNI bridge to the upstream `crimson-rs` parser.
- Inventory listing with item number (`itemNo`), item key, inventory key, container, slot and stack count.
- Duplicate cleanup keyed by `itemNo` (the item type number), not by the potentially instance-specific `itemKey`.
- One matching entry is retained per inventory container; additional matching entries are removed in descending list-index order.
- Uses the actual `_inventorylist` and `_itemList` field indices read from the decoded schema. The GitHub Actions build patches the upstream C ABI record to expose these indices; the patch aborts the build if the expected upstream source shape has changed.
- Atomic native batch mutation with rollback on failure.
- Reopens the exported save and checks that it parses, that the requested item number has no remaining repeated entries per container, and that the total inventory count changed by exactly the removed count.

## Important limitations
- The item number for the duplicated starting sword is **not known yet**. The app lists numeric IDs; it does not have a verified name database and cannot identify the sword automatically.
- Compatibility with Crimson Desert build `01.000.151` has not been confirmed by a real round-trip test.
- The APK has not been built in this local environment. Use the included GitHub Actions workflow to build the ARM64 debug APK.
- The cleanup assumes that repeated records with the same `itemNo` in the same inventory container are unwanted duplicates. Review the selected item number and work on a backup copy.

## Build an APK
1. Put this project in a GitHub repository.
2. Open **Actions → Build Android ARM64 APK** and run the workflow (or push to `main`).
3. Download the artifact `CrimsonSaveInspector-arm64-debug` from the completed workflow run.
4. Install `app-debug.apk` on an ARM64 Android device.

The workflow builds `libcrimson_rs.so` from upstream source, applies the schema-index patch, builds the JNI bridge, then assembles the Android debug APK.

## Safe test sequence
1. Keep the backup you already made.
2. First open the save and inspect the inventory list; do not run cleanup until the duplicated sword's exact `itemNo` is identified.
3. Export a cleaned copy to a new filename.
4. Confirm the exported copy is parseable and only then test it in-game.

The app does not connect to PSN or modify the PS5 directly. Transferring the exported file back to the console is a separate step.
