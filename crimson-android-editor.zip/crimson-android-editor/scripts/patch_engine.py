"""Patch crimson-rs inventory records to expose schema-derived list field indices.

The editor must never assume `_inventorylist` / `_itemList` occupy fixed
numeric field slots. This patch extends the repr(C) record with the exact
field_index values found while walking the decoded schema.
"""
from pathlib import Path
p = Path('src/c_abi/mod.rs')
s = p.read_text()
old_struct = '''pub struct CrimsonInventoryItemRecord {
    pub block_idx: u32,
    pub inventory_element_idx: u32,'''
new_struct = '''pub struct CrimsonInventoryItemRecord {
    pub block_idx: u32,
    pub inventory_list_field_idx: u32,
    pub item_list_field_idx: u32,
    pub inventory_element_idx: u32,'''
if old_struct not in s:
    raise SystemExit('Could not locate CrimsonInventoryItemRecord layout; refusing unsafe build')
s = s.replace(old_struct, new_struct, 1)
s = s.replace('48-byte structure', '56-byte structure')
old_init = '''                            let mut rec = CrimsonInventoryItemRecord {
                                block_idx: block_idx as u32,
                                inventory_element_idx: inv_idx as u32,'''
new_init = '''                            let mut rec = CrimsonInventoryItemRecord {
                                block_idx: block_idx as u32,
                                inventory_list_field_idx: inv_list_field.field_index,
                                item_list_field_idx: f.field_index,
                                inventory_element_idx: inv_idx as u32,'''
if old_init not in s:
    raise SystemExit('Could not locate inventory record initializer; refusing unsafe build')
s = s.replace(old_init, new_init, 1)
p.write_text(s)
print('Patched schema-derived inventory field indices into C ABI record')
