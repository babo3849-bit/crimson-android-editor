# Verified native engine integration (upstream `crimson-rs`)

This note records the concrete API discovered in the upstream Rust source. It is not a claim that the Android binary has been built.

## Save lifecycle

The C ABI exposes `crimson_save_load_from_file(path, &handle)`, `crimson_save_free(handle)`, and `crimson_save_write_to_file(handle, path)`. Loading runs `Save::parse`, `Body::parse`, and `Body::decode_blocks`; writing re-encodes the body and updates the compressed/encrypted payload and HMAC. The write call refuses to run while a deferred mutation batch is open.

## Inventory discovery

`crimson_save_list_inventory_items(handle, records, capacity, &count, &version)` enumerates items across every `InventorySaveData` block and every `_inventorylist` container. The `repr(C)` record is 48 bytes and includes:

- `block_idx`
- `inventory_element_idx`
- `item_element_idx`
- `inventory_key`, `item_key`, `transferred_item_key`, `slot_no`, `flags`
- `item_no`, `stack_count`

The API uses a two-call buffer-sizing pattern. The version value allows the app to detect when a prior list snapshot has become stale after an edit.

## Removing an item-list entry

`crimson_save_list_remove_element(handle, block_idx, path, path_len, field_idx, element_idx)` removes an element from an object-list field and updates its list count. `CrimsonPathStep` is a pair of `u32` values (`field_idx`, `element_idx`) used to navigate nested objects. The bulk counterpart `crimson_save_list_remove_elements_batch` supports all-or-nothing removal batches and sorts removals within the same list by descending element index to avoid index shifts.

## UI requirements before enabling edits

1. Show a parsed inventory snapshot with container, item key, item number, and stack count.
2. Resolve each row to the exact nested list path and list-field index before offering deletion. The flat inventory record alone is not enough to call the removal API safely.
3. Require explicit selection; never bulk-delete every item with a matching display name automatically.
4. Save to a separate output file, reopen it through the parser, and verify HMAC + item count before presenting it as successful.
5. Preserve the original input file and warn that an unrecognized/quest-critical item may be required by a mission.

## Android status

The current Android folder is a starter shell only. It does not yet contain an Android ARM64 `libcrimson_rs.so`, JNI bindings, or a tested APK. The build environment used for this work has Java 21 but no `cargo`, Gradle executable, or Android SDK configured. Therefore no installable APK can honestly be supplied from this environment yet.
