# Port plan

## Source findings

- `Atomic-Flip/CRIMSON-DESERT-SAVE-EDITOR-AND-GAME-MODS` contains a PySide desktop editor. Its `save_crypto.py` uses a SAVE header, ChaCha20, LZ4 and HMAC. Its `item_scanner.py` limits item scans to named item-bearing classes; fallback scanning is heuristic. This can omit items outside expected containers.
- `bbfox0703/CrimsonAtomtic` uses a generic save block/field tree plus inventory container enumeration. The project README describes generic block navigation, item lists per container, search and structural edits. Rust (`crimson-rs`) owns format parsing and serialization; Avalonia UI and .NET 10 are platform layers.
- The CrimsonAtomtic repository's README says its vendored Rust crate is cloned from `https://github.com/bbfox0703/crimson-rs.git`. This repository is not available through the current GitHub read API, so exact exported C ABI names must be acquired before JNI bindings can be written.
- Avalonia 12 officially supports Android on .NET 10, though the existing CrimsonAtomtic UI project is configured as a Windows desktop WinExe. A dedicated Android target or Kotlin shell is required.

## Required next engineering steps

1. Read `bbfox0703/crimson-rs` C ABI header/export module and its Cargo features.
2. Add Android NDK targets (`aarch64-linux-android`) for the Rust crate; package `.so` in `jniLibs/arm64-v8a`.
3. Bind C ABI with JNI or JNA only after verifying function signatures and ownership rules.
4. Implement generic block tree UI; never filter blocks to Inventory/Equipment only.
5. Inventory search must enumerate every list field/element, including quest artefacts and containers with unfamiliar names. Surface unknown keys by numeric item key and raw fields rather than suppressing them.
6. Editing: remove a selected duplicate list element (preserve one selected wolf sword), serialize, recompute container crypto, reopen output, validate structure and HMAC, then allow export.
7. Test on copies from the exact PS5 export layout and game patch before enabling writes.

## Safety gates

- Never patch encrypted bytes directly by searching for display strings.
- Never write when schema decode has undecoded structural ranges in the target list.
- Keep an immutable input copy and create a timestamped output copy.
- Do a parse -> serialize -> reopen round-trip check before export.
