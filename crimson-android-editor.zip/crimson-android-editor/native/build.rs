fn main() {
    let dir = std::env::var("CRIMSON_ENGINE_LIB_DIR").expect("CRIMSON_ENGINE_LIB_DIR must point to the built crimson-rs shared library");
    println!("cargo:rustc-link-search=native={dir}");
    println!("cargo:rustc-link-lib=dylib=crimson_rs");
}
