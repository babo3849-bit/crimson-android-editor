use jni::objects::{JObject, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use std::ffi::{c_char, c_void, CString};
use std::ptr;

#[repr(C)]
struct InventoryItemRecord {
    block_idx: u32,
    inventory_list_field_idx: u32,
    item_list_field_idx: u32,
    inventory_element_idx: u32,
    item_element_idx: u32,
    inventory_key: u32,
    item_key: u32,
    transferred_item_key: u32,
    slot_no: u32,
    flags: u32,
    item_no: u64,
    stack_count: u64,
}

#[repr(C)]
struct SaveHandle { _private: [u8; 0] }

#[repr(C)]
struct PathStep { field_idx: u32, element_idx: u32 }

#[repr(C)]
struct ListRemoveBatchOp {
    block_idx: u32,
    field_idx: u32,
    path: *const PathStep,
    path_len: usize,
    element_idx: u32,
}

#[link(name = "crimson_rs", kind = "dylib")]
unsafe extern "C" {
    fn crimson_save_load_from_file(path: *const c_char, out: *mut *mut SaveHandle) -> i32;
    fn crimson_save_free(handle: *mut SaveHandle);
    fn crimson_save_write_to_file(handle: *const SaveHandle, path: *const c_char) -> i32;
    fn crimson_save_list_remove_elements_batch(
        handle: *mut SaveHandle,
        ops: *const ListRemoveBatchOp,
        op_count: usize,
        out_failed_op_index: *mut usize,
    ) -> i32;
    fn crimson_save_list_inventory_items(
        handle: *const SaveHandle,
        records: *mut InventoryItemRecord,
        capacity: usize,
        out_count: *mut usize,
        out_version: *mut u64,
    ) -> i32;
}

fn json_error(message: &str) -> String {
    let escaped = serde_json::to_string(message).unwrap_or_else(|_| "\"Unbekannter Fehler\"".to_string());
    format!("{{\"ok\":false,\"error\":{escaped}}}")
}

#[no_mangle]
pub extern "system" fn Java_com_crimson_editor_NativeBridge_inventoryJson(
    mut env: JNIEnv,
    _this: JObject,
    path: JString,
) -> jstring {
    let result = (|| -> Result<String, String> {
        let path: String = env.get_string(&path).map_err(|e| e.to_string())?.into();
        let cpath = CString::new(path).map_err(|_| "Ungültiger Dateipfad".to_string())?;
        let mut handle: *mut SaveHandle = ptr::null_mut();
        let rc = unsafe { crimson_save_load_from_file(cpath.as_ptr(), &mut handle) };
        if rc != 0 || handle.is_null() {
            return Err(format!("Spielstand konnte nicht gelesen werden (Parser-Code {rc})"));
        }
        let output = (|| {
            let mut count = 0usize;
            let mut version = 0u64;
            let size_rc = unsafe { crimson_save_list_inventory_items(handle, ptr::null_mut(), 0, &mut count, &mut version) };
            if size_rc != 0 && count == 0 {
                return Err(format!("Inventar konnte nicht gelesen werden (Code {size_rc})"));
            }
            let mut records: Vec<InventoryItemRecord> = Vec::with_capacity(count);
            let read_rc = unsafe { crimson_save_list_inventory_items(handle, records.as_mut_ptr(), count, &mut count, &mut version) };
            if read_rc != 0 { return Err(format!("Inventarliste fehlgeschlagen (Code {read_rc})")); }
            unsafe { records.set_len(count); }
            let rows = records.iter().map(|r| format!(
                "{{\"block\":{},\"container\":{},\"slotIndex\":{},\"inventoryKey\":{},\"itemKey\":{},\"transferredItemKey\":{},\"slotNo\":{},\"flags\":{},\"itemNo\":{},\"stackCount\":{}}}",
                r.block_idx, r.inventory_element_idx, r.item_element_idx, r.inventory_key,
                r.item_key, r.transferred_item_key, r.slot_no, r.flags, r.item_no, r.stack_count
            )).collect::<Vec<_>>().join(",");
            Ok(format!("{{\"ok\":true,\"count\":{},\"version\":{},\"items\":[{}]}}", count, version, rows))
        })();
        unsafe { crimson_save_free(handle); }
        output
    })();
    let text = result.unwrap_or_else(|e| json_error(&e));
    env.new_string(text).map(|s| s.into_raw()).unwrap_or(ptr::null_mut())
}


#[no_mangle]
pub extern "system" fn Java_com_crimson_editor_NativeBridge_removeDuplicates(
    mut env: JNIEnv, _this: JObject, input: JString, output: JString, item_no: jni::sys::jlong,
) -> jstring {
    let result = (|| -> Result<String, String> {
        let input: String = env.get_string(&input).map_err(|e| e.to_string())?.into();
        let output: String = env.get_string(&output).map_err(|e| e.to_string())?.into();
        let in_path = CString::new(input).map_err(|_| "Ungültiger Eingabepfad".to_string())?;
        let out_path = CString::new(output).map_err(|_| "Ungültiger Ausgabepfad".to_string())?;
        if item_no <= 0 { return Err("Item-Nummer muss größer als 0 sein".into()); }
        let mut handle: *mut SaveHandle = ptr::null_mut();
        let rc = unsafe { crimson_save_load_from_file(in_path.as_ptr(), &mut handle) };
        if rc != 0 || handle.is_null() { return Err(format!("Spielstand konnte nicht gelesen werden (Code {rc})")); }
        let operation = (|| -> Result<String, String> {
            let mut count = 0usize; let mut version = 0u64;
            let rc = unsafe { crimson_save_list_inventory_items(handle, ptr::null_mut(), 0, &mut count, &mut version) };
            if rc != 0 && count == 0 { return Err(format!("Inventarfehler (Code {rc})")); }
            let mut records: Vec<InventoryItemRecord> = Vec::with_capacity(count);
            let rc = unsafe { crimson_save_list_inventory_items(handle, records.as_mut_ptr(), count, &mut count, &mut version) };
            if rc != 0 { return Err(format!("Inventarliste fehlgeschlagen (Code {rc})")); }
            unsafe { records.set_len(count); }
            let target_item_no = item_no as u64;
            // Never collapse matching item types across different inventory containers.
            // A legitimate copy in another container is preserved. Only repeated entries
            // inside the exact same InventorySaveData/_inventorylist container are candidates.
            use std::collections::BTreeMap;
            let mut groups: BTreeMap<(u32, u32, u32), Vec<InventoryItemRecord>> = BTreeMap::new();
            for record in records.into_iter().filter(|r| r.item_no == target_item_no) {
                groups.entry((record.block_idx, record.inventory_element_idx, record.item_no))
                    .or_default().push(record);
            }
            let mut removals: Vec<InventoryItemRecord> = Vec::new();
            let mut matched_containers = 0usize;
            let mut kept_groups = 0usize;
            for (_group, mut entries) in groups {
                entries.sort_by_key(|r| r.item_element_idx);
                if !entries.is_empty() {
                    kept_groups += 1;
                    if entries.len() > 1 {
                        matched_containers += 1;
                        removals.extend(entries.into_iter().skip(1));
                    }
                }
            }
            if removals.is_empty() {
                return Err(format!("Für Item-Nummer {target_item_no} wurden innerhalb einzelner Inventar-Container keine Duplikate gefunden. Es bleibt alles unverändert."));
            }
            // The upstream batch API applies all removals atomically and re-encodes
            // only once. Sort descending within each _itemList so indexes never shift.
            removals.sort_by(|a,b| a.block_idx.cmp(&b.block_idx)
                .then(a.inventory_element_idx.cmp(&b.inventory_element_idx))
                .then(b.item_element_idx.cmp(&a.item_element_idx)));
            let duplicate_count = removals.len();
            let paths: Vec<[PathStep; 1]> = removals.iter().map(|rec| [
                PathStep { field_idx: rec.inventory_list_field_idx, element_idx: rec.inventory_element_idx }
            ]).collect();
            let ops: Vec<ListRemoveBatchOp> = removals.iter().zip(paths.iter()).map(|(rec, path)| ListRemoveBatchOp {
                block_idx: rec.block_idx,
                field_idx: rec.item_list_field_idx,
                path: path.as_ptr(),
                path_len: path.len(),
                element_idx: rec.item_element_idx,
            }).collect();
            let mut failed_op = usize::MAX;
            let rc = unsafe { crimson_save_list_remove_elements_batch(handle, ops.as_ptr(), ops.len(), &mut failed_op) };
            if rc != 0 {
                return Err(format!("Löschen wurde vollständig zurückgerollt (Parser-Code {rc}, Operation {failed_op}). Es wurde keine Ausgabedatei geschrieben."));
            }
            let rc = unsafe { crimson_save_write_to_file(handle, out_path.as_ptr()) };
            if rc != 0 { return Err(format!("Export fehlgeschlagen (Code {rc})")); }
            // Re-open the exported save and confirm it can be parsed and the targeted
            // duplicates are gone before reporting success.
            let mut verify: *mut SaveHandle = ptr::null_mut();
            let verify_rc = unsafe { crimson_save_load_from_file(out_path.as_ptr(), &mut verify) };
            if verify_rc != 0 || verify.is_null() {
                return Err(format!("Die gespeicherte Datei konnte nicht erneut geprüft werden (Code {verify_rc}). Bitte nicht im Spiel verwenden."));
            }
            let verify_result = (|| -> Result<usize, String> {
                let mut verify_count = 0usize;
                let mut verify_version = 0u64;
                let size_rc = unsafe { crimson_save_list_inventory_items(verify, ptr::null_mut(), 0, &mut verify_count, &mut verify_version) };
                if size_rc != 0 && verify_count == 0 { return Err(format!("Prüfung der Inventarliste fehlgeschlagen (Code {size_rc})")); }
                let mut verify_records: Vec<InventoryItemRecord> = Vec::with_capacity(verify_count);
                let read_rc = unsafe { crimson_save_list_inventory_items(verify, verify_records.as_mut_ptr(), verify_count, &mut verify_count, &mut verify_version) };
                if read_rc != 0 { return Err(format!("Prüfung der Inventarliste fehlgeschlagen (Code {read_rc})")); }
                unsafe { verify_records.set_len(verify_count); }
                let remaining = verify_records.iter().filter(|r| r.item_no == target_item_no)
                    .fold(BTreeMap::<(u32,u32,u32), usize>::new(), |mut acc, r| {
                        *acc.entry((r.block_idx, r.inventory_element_idx, r.item_no)).or_insert(0) += 1; acc
                    });
                if remaining.values().any(|n| *n > 1) {
                    return Err("Nachprüfung: In mindestens einem Container sind noch Duplikate vorhanden.".into());
                }
                let remaining_target_items: usize = remaining.values().sum();
                if remaining_target_items != kept_groups || verify_count + duplicate_count != count {
                    return Err("Nachprüfung: Die Anzahl der Einträge stimmt nicht mit der geplanten Bereinigung überein.".into());
                }
                Ok(verify_count)
            })();
            unsafe { crimson_save_free(verify); }
            let verified_total = verify_result?;
            Ok(format!("{{\"ok\":true,\"itemNo\":{target_item_no},\"removed\":{duplicate_count},\"keptEntries\":{kept_groups},\"containersWithDuplicates\":{matched_containers},\"verifiedInventoryCount\":{verified_total}}}"))
        })();
        unsafe { crimson_save_free(handle); }
        operation
    })();
    let text = result.unwrap_or_else(|e| json_error(&e));
    env.new_string(text).map(|s| s.into_raw()).unwrap_or(ptr::null_mut())
}

// Keep ABI type visible to Rust's linker; the C engine owns the handle.
const _: Option<*mut c_void> = None;
