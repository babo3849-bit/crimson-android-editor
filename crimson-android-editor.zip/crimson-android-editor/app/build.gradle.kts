plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.crimson.editor"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.crimson.editor"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "0.3.0-schema-indexed-prototype"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
}
