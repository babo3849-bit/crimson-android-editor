package com.crimson.editor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.io.File

/** Android UI for inspecting inventory and exporting a cleaned COPY of a save. */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var preview: LinearLayout
    private lateinit var itemNoInput: EditText
    private lateinit var exportButton: Button
    private var inputFile: File? = null
    private var pendingOutputFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF101418.toInt())
        }
        val title = TextView(this).apply {
            text = "CRIMSON DESERT\nSAVE INSPECTOR"
            textSize = 23f
            setTextColor(0xFFFFC66D.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Noch keine Save-Datei geöffnet"
            setTextColor(0xFFE4E8EC.toInt())
            textSize = 14f
        }
        val open = Button(this).apply {
            text = "SAVE-DATEI ÖFFNEN"
            setOnClickListener { pickSave() }
        }
        itemNoInput = EditText(this).apply {
            hint = "Item-Nummer (itemNo) eingeben"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA4AE.toInt())
            isEnabled = false
        }
        exportButton = Button(this).apply {
            text = "DUPLIKATE ENTFERNEN & KOPIE EXPORTIEREN"
            isEnabled = false
            setOnClickListener { chooseOutput() }
        }
        preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this).apply {
                text = "Hier erscheinen die ausgelesenen Inventar-Einträge.\n\nWichtig: Zuerst eine Sicherung deiner Save-Datei machen."
                textSize = 13f
                setTextColor(0xFFD1D7DE.toInt())
                setPadding(8, 16, 8, 16)
            })
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 120))
        root.addView(open, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(status, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(itemNoInput, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(exportButton, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        val scroll = ScrollView(this).apply { addView(preview) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun pickSave() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, REQUEST_OPEN)
    }

    private fun chooseOutput() {
        val key = itemNoInput.text.toString().trim().toLongOrNull()
        if (key == null || key <= 0) {
            status.text = "Bitte eine gültige Item-Nummer eingeben."
            return
        }
        if (inputFile == null) return
        android.app.AlertDialog.Builder(this)
            .setTitle("Duplikate wirklich entfernen?")
            .setMessage("Es werden zusätzliche Einträge mit Item-Nummer $key innerhalb desselben Inventar-Containers entfernt. Ein Exemplar pro Container bleibt erhalten. Es wird eine neue Datei erstellt; dein Original bleibt unverändert. Prüfe, dass die Nummer wirklich zum doppelten Schwert gehört.")
            .setNegativeButton("Abbrechen", null)
            .setPositiveButton("Weiter") { _, _ -> createOutputDocument(key) }
            .show()
    }

    private fun createOutputDocument(key: Long) {
        pendingOutputFile = File(cacheDir, "crimson_cleaned_${System.currentTimeMillis()}.save")
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, "CrimsonDesert_cleaned.save")
        }
        getPreferences(MODE_PRIVATE).edit().putLong("pending_item_no", key).apply()
        startActivityForResult(intent, REQUEST_CREATE)
    }

    @Deprecated("Uses the platform document picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQUEST_OPEN -> loadSave(uri)
            REQUEST_CREATE -> exportCleanedCopy(uri)
        }
    }

    private fun loadSave(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Datei konnte nicht gelesen werden")
            val file = File(cacheDir, "selected_crimson_save.save")
            file.writeBytes(bytes)
            inputFile = file
            if (!NativeBridge.initialize()) {
                status.text = "Datei geladen (${bytes.size} Bytes), aber Parser-Bibliothek fehlt."
                preview.removeAllViews()
                preview.addView(TextView(this).apply {
                    text = "Diese APK benötigt die ARM64-Parserbibliothek libcrimson_rs.so und die JNI-Brücke."
                    setTextColor(0xFFD1D7DE.toInt())
                    setPadding(8, 16, 8, 16)
                })
                return
            }
            val response = JSONObject(NativeBridge.inventoryJson(file.absolutePath))
            if (!response.optBoolean("ok")) error(response.optString("error", "Unbekannter Parserfehler"))
            val items = response.optJSONArray("items")
            preview.removeAllViews()
            preview.addView(TextView(this).apply {
                text = "Inventar-Einträge: ${response.optInt("count")}\nTippe einen Eintrag an, um seine Item-Nummer zu übernehmen.\n"
                setTextColor(0xFFFFC66D.toInt())
                setPadding(8, 12, 8, 12)
            })
            if (items != null) for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val key = item.optLong("itemKey")
                val row = TextView(this).apply {
                    text = "Item-Nr.: ${item.optLong("itemNo")}\nItem-Schlüssel: $key | Inventar: ${item.optInt("inventoryKey")} | Container: ${item.optInt("container")} | Slot: ${item.optInt("slotNo")} | Stack: ${item.optLong("stackCount")}\n"
                    textSize = 13f
                    setTextColor(0xFFD1D7DE.toInt())
                    setPadding(12, 12, 12, 12)
                    setOnClickListener {
                        itemNoInput.setText(item.optLong("itemNo").toString())
                        status.text = "Item-Nummer ${item.optLong("itemNo")} ausgewählt. Bitte vor dem Export anhand der Einträge prüfen."
                    }
                }
                preview.addView(row)
                val divider = android.view.View(this).apply { setBackgroundColor(0xFF35404A.toInt()) }
                preview.addView(divider, LinearLayout.LayoutParams(-1, 1))
            }
            status.text = "Save gelesen. Tippe den passenden Inventar-Eintrag an, um seine Item-Nummer zu übernehmen."
            itemNoInput.isEnabled = true
            exportButton.isEnabled = true
        } catch (e: Exception) {
            status.text = "Fehler: ${e.message}"
            itemNoInput.isEnabled = false
            exportButton.isEnabled = false
        }
    }

    private fun exportCleanedCopy(destination: Uri) {
        val source = inputFile ?: return
        val target = pendingOutputFile ?: return
        val key = getPreferences(MODE_PRIVATE).getLong("pending_item_no", -1L)
        try {
            status.text = "Duplikate werden entfernt …"
            val response = JSONObject(NativeBridge.removeDuplicates(source.absolutePath, target.absolutePath, key))
            if (!response.optBoolean("ok")) error(response.optString("error", "Bearbeitung fehlgeschlagen"))
            contentResolver.openOutputStream(destination, "w")?.use { out -> target.inputStream().use { it.copyTo(out) } }
                ?: error("Zieldatei konnte nicht geschrieben werden")
            status.text = "Fertig und erneut geprüft: ${response.optInt("removed")} Duplikate entfernt. Original bleibt unverändert."
            preview.removeAllViews()
            preview.addView(TextView(this).apply {
                text = "Bereinigte Kopie exportiert und erneut eingelesen.\nItem-Nummer: ${response.optLong("itemNo")}\nEntfernt: ${response.optInt("removed")}\nContainer mit Duplikaten: ${response.optInt("containersWithDuplicates")}\nEinträge (je Container ein Exemplar behalten): ${response.optInt("keptEntries")}\nInventar-Einträge nach Prüfung: ${response.optInt("verifiedInventoryCount")}"
                setTextColor(0xFFD1D7DE.toInt())
                setPadding(8, 16, 8, 16)
            })
        } catch (e: Exception) {
            status.text = "Export abgebrochen: ${e.message}"
        }
    }

    companion object {
        private const val REQUEST_OPEN = 410
        private const val REQUEST_CREATE = 411
    }
}
