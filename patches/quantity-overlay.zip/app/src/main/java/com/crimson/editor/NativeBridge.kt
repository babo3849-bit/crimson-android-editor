package com.crimson.editor

/** JNI adapter backed by the upstream crimson-rs parser. */
object NativeBridge {
    @Volatile var available: Boolean = false
        private set

    fun initialize(): Boolean {
        return try {
            System.loadLibrary("crimson_android_bridge")
            available = true
            true
        } catch (_: UnsatisfiedLinkError) {
            available = false
            false
        }
    }

    external fun inventoryJson(absolutePath: String): String
    external fun removeDuplicates(inputPath: String, outputPath: String, itemKey: Long): String
    external fun setStackCount(inputPath: String, outputPath: String, block: Int, inventoryField: Int, container: Int, itemField: Int, itemIndex: Int, count: Long): String
}
